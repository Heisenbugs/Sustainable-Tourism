<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Districtmodel extends CI_Model {
	public function add($data){
		$this->db->insert('district',$data);
	}

	

}

/* End of file Districtmodel.php */
/* Location: ./application/models/Districtmodel.php */