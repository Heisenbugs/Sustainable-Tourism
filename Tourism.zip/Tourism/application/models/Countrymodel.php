<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Countrymodel extends CI_Model {

	public function add($data){
		$this->db->insert('country',$data);
	}
	

}

/* End of file Countrymodel.php */
/* Location: ./application/models/Countrymodel.php */