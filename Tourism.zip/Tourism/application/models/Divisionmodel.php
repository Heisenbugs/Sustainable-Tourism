<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Divisionmodel extends CI_Model {

	public function add($data){
		$this->db->insert('division',$data);
	}

}

/* End of file Divisionmodel.php */
/* Location: ./application/models/Divisionmodel.php */