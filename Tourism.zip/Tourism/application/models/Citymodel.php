<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Citymodel extends CI_Model {

	public function show_country(){
		$this->db->select('country_id, country_name');
		$this->db->from('country');
		return $this->db->get()->result_array();
	}

	public function add($data){
		$this->db->insert('city',$data);
	}

}

/* End of file Citymodel.php */
/* Location: ./application/models/Citymodel.php */