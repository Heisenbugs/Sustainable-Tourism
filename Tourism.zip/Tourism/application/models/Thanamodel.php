<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Thanamodel extends CI_Model {

	public function add($data){
		$this->db->insert('thana',$data);
	}

}

/* End of file Thanamodel.php */
/* Location: ./application/models/Thanamodel.php */