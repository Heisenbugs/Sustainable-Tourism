<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tagsmodel extends CI_Model {

	public function add($data){
		$this->db->insert('tags',$data);		
	}

}

/* End of file Tagsmodel.php */
/* Location: ./application/models/Tagsmodel.php */