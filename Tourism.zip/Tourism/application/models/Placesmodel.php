<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Placesmodel extends CI_Model {

	public function show_country(){
		$this->db->select('country_id, country_name');
		$this->db->from('country');
		return $this->db->get()->result_array();
	}

	public function show_city(){
		$this->db->select('city_id, city_name');
		$this->db->from('city');
		return $this->db->get()->result_array();
	}

	public function show_district(){
		$this->db->select('district_id, district_name');
		$this->db->from('district');
		return $this->db->get()->result_array();
	}

	public function show_thana(){
		$this->db->select('thana_id, thana_name');
		$this->db->from('thana');
		return $this->db->get()->result_array();
	}


	public function show_division(){
		$this->db->select('division_id, division_name');
		$this->db->from('division');
		return $this->db->get()->result_array();
	}

	public function add_address($data){
		$this->db->insert('address',$data);

		$this->db->select_max('address_id');
		$query = $this->db->get('address');
		return $query->row();
	}

	public function show_tags(){
		$this->db->select('tag_id, tag_name');
		$this->db->from('tags');
		return $this->db->get()->result_array();
	}

	public function add_place($data){
		$this->db->insert('places',$data);

		$this->db->select_max('place_id');
		$query = $this->db->get('places');
		return $query->row();
	}

	public function add_tags($dt,$tags){
		foreach ($tags as $key => $value) {
			$data = array(
				'place_id' => $dt,
				'tag_id' => $value
				);	
			
			$this->db->insert('placetag', $data);		
		}
	}
}

/* End of file Placesmodel.php */
/* Location: ./application/models/Placesmodel.php */