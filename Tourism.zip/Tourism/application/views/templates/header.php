<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title></title>

	<!-- Font awesome -->
	<link rel="stylesheet" href="<?php echo base_url()?>assets/css/font-awesome.min.css">
	<!-- Sandstone Bootstrap CSS -->
	<link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.min.css">
	<!-- Bootstrap Datatables -->
	<link rel="stylesheet" href="<?php echo base_url()?>assets/css/dataTables.bootstrap.min.css">
	<!-- Bootstrap social button library -->
	<link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap-social.css">
	<!-- Bootstrap select -->
	<link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap-select.css">
	<!-- Bootstrap file input -->
	<link rel="stylesheet" href="<?php echo base_url()?>assets/css/fileinput.min.css">
	<!-- Awesome Bootstrap checkbox -->
	<link rel="stylesheet" href="<?php echo base_url()?>assets/css/awesome-bootstrap-checkbox.css">
	<!-- Admin Stye -->
	<link rel="stylesheet" href="<?php echo base_url()?>assets/css/stylesheet.css">


</head>

<body>
	<div class="brand clearfix">
		<a href="index.html" class="logo"><img src="img/logo.jpg" class="img-responsive" alt=""></a>
		<span class="menu-btn"><i class="fa fa-bars"></i></span>
		<ul class="ts-profile-nav">
			<li><a href="#">Help</a></li>
			<li><a href="#">Settings</a></li>
			<li class="ts-account">
				<a href="#"><img src="img/ts-avatar.jpg" class="ts-avatar hidden-side" alt=""> Account <i class="fa fa-angle-down hidden-side"></i></a>
				<ul>
					<li><a href="#">My Account</a></li>
					<li><a href="#">Edit Account</a></li>
					<li><a href="#">Logout</a></li>
				</ul>
			</li>
		</ul>
	</div>

	<div class="ts-main-content">
		<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
				<li class="ts-label">Search</li>
				<li>
					<input type="text" class="ts-sidebar-search" placeholder="Search here...">
				</li>
				<li class="ts-label">Main</li>
				<li class="open"><a href=""><i class="fa fa-dashboard"></i> Dashboard</a></li>

				<li class="open"><a href="<?php echo base_url()?>/index.php/Places"><i class="fa fa-dashboard"></i> Add new place</a></li>
				<li class="open"><a href=""><i class="fa fa-dashboard"></i> Add new admin</a></li>

				<li><a href="#"><i class="fa fa-sitemap"></i> Address addition</a>
					<ul>
						<li><a href="<?php echo base_url()?>/index.php/City">Add city</a></li>
						<li><a href="<?php echo base_url()?>/index.php/Country">Add country</a></li>
						<li><a href="<?php echo base_url()?>/index.php/District">Add district</a></li>
						<li><a href="<?php echo base_url()?>/index.php/Tags">Add place tags</a></li>
						<li><a href="<?php echo base_url()?>/index.php/Thana">Add thana</a></li>
						<li><a href="<?php echo base_url()?>/index.php/Division">Add division</a></li>
					</ul>
				</li>

				<li><a href="#"><i class="fa fa-sitemap"></i>Tables</a>
					<ul>
						<li><a href="#">places</a></li>
						<li><a href="#">admins</a></li>
						<li><a href="#">travellers</a></li>
						<li><a href="#">guides</a></li>
						<li><a href="#">organizations</a></li>
						<li><a href="#">cities</a></li>
						<li><a href="#">countries</a></li>
						<li><a href="#">districts</a></li>
						<li><a href="#">thanas</a></li>
						<li><a href="#">divisions</a></li>
					</ul>
				</li>


				<!-- Account from above -->
				<ul class="ts-profile-nav">
					<li><a href="#">Help</a></li>
					<li><a href="#">Settings</a></li>
					<li class="ts-account">
						<a href="#"><img src="img/ts-avatar.jpg" class="ts-avatar hidden-side" alt=""> Account <i class="fa fa-angle-down hidden-side"></i></a>
						<ul>
							<li><a href="#">My Account</a></li>
							<li><a href="#">Edit Account</a></li>
							<li><a href="#">Logout</a></li>
						</ul>
					</li>
				</ul>

			</ul>
		</nav>

		