<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SignUpModel extends CI_Model {
	
	

}

/* End of file SignUpModel.php */
/* Location: ./application/views/SignUpModel.php */