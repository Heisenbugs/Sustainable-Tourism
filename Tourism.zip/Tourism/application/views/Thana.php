<?php include 'templates/header.php';?>
<div class="content-wrapper">
	<div class="container-fluid">

		<div class="row">
			<div class="col-md-12">

				<h2 class="page-title">Add new Thana</h2>

				<div class="row">
					<div class="col-md-8">
						<div class="panel panel-default">
							<div class="panel-heading">Please provide required information</div>
							<div class="panel-body">
								<form method="post" action="<?php echo base_url()?>/index.php/Thana/add_thana" class="form-horizontal">
									<div class="form-group">
										<label class="col-sm-2 control-label">Thana name: </label>
										<div class="col-sm-10">
											<input type="text" name="thananame" class="form-control">
										</div>
									</div>


									<div class="hr-dashed"></div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Thana code</label>
										<div class="col-sm-10">
											<input type="text" name="code" class="form-control"></div>
										</div>

										


										<div class="form-group">
											<div class="col-sm-4 col-sm-offset-5">
												<button class="btn btn-default" type="submit">Cancel</button>
												<button class="btn btn-primary" type="submit">Save changes</button>
											</div>
										</div>

									</form>

								</div>
							</div>
						</div>
					</div>
				</div>


				<?php include 'templates/footer.php';?>