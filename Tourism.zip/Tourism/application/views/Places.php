<?php include 'templates/header.php';?>
<div class="content-wrapper">
	<div class="container-fluid">

		<div class="row">
			<div class="col-md-12">

				<h2 class="page-title">Add new place</h2>

				<div class="row">
					<div class="col-md-8">
						<div class="panel panel-default">
							<div class="panel-heading">Please provide required information</div>
							<div class="panel-body">
								<form method="post" action="<?php echo base_url()?>/index.php/Places/add_places" class="form-horizontal">
									<div class="form-group">
										<label class="col-sm-2 control-label">Place name: </label>
										<div class="col-sm-10">
											<input type="text" name="placename" class="form-control">
										</div>
									</div>


									<div class="hr-dashed"></div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Description</label>
										<div class="col-sm-10">
											<input type="text" name="description" class="form-control"></div>
										</div>

										
										<div class="form-group">
											<label class="col-sm-2 control-label">Country:</label>
											<div class="col-sm-10"> 
												<select class="form-control" name="country_id" style="width:350px;">
													<option value="" disabled selected>Select a country</option>
													<?php foreach ($Country as $key => $value) { ?>
													<option value="<?php echo $value['country_id'];?>"><?php echo $value['country_name'];?></option>
													<?php } ?>
												</select>
											</div>
										</div>

										<div class="form-group">
											<label class="col-sm-2 control-label">City:</label>
											<div class="col-sm-10"> 
												<select class="form-control" name="city_id" style="width:350px;">
													<option value="" disabled selected>Select a city</option>
													<?php foreach ($City as $key => $value) { ?>
													<option value="<?php echo $value['city_id'];?>"><?php echo $value['city_name'];?></option>
													<?php } ?>
												</select>
											</div>
										</div>

										<div class="form-group">
											<label class="col-sm-2 control-label">District:</label>
											<div class="col-sm-10"> 
												<select class="form-control" name="district_id" style="width:350px;">
													<option value="" disabled selected>Select a district</option>
													<?php foreach ($District as $key => $value) { ?>
													<option value="<?php echo $value['district_id'];?>"><?php echo $value['district_name'];?></option>
													<?php } ?>
												</select>
											</div>
										</div>

										<div class="form-group">
											<label class="col-sm-2 control-label">Division:</label>
											<div class="col-sm-10"> 
												<select class="form-control" name="division_id" style="width:350px;">
													<option value="" disabled selected>Select a division</option>
													<?php foreach ($Division as $key => $value) { ?>
													<option value="<?php echo $value['division_id'];?>"><?php echo $value['division_name'];?></option>
													<?php } ?>
												</select>
											</div>
										</div>

										<div class="form-group">
											<label class="col-sm-2 control-label">Thana:</label>
											<div class="col-sm-10"> 
												<select  class="form-control" name="thana_id" style="width:350px;">
													<option value="" disabled selected>Select a division</option>
													<?php foreach ($Thana as $key => $value) { ?>
													<option value="<?php echo $value['thana_id'];?>"><?php echo $value['thana_name'];?></option>
													<?php } ?>
												</select>
											</div>
										</div>

										<div class="form-group">
											<label class="col-sm-2 control-label">Tags:</label>
											<div class="col-sm-10"> 
												<select multiple="multiple" class="form-control" name="tag_id[]" style="width:350px;">
													<option value="" disabled selected>Select tags</option>
													<?php foreach ($Tags as $key => $value) { ?>
													<option value="<?php echo $value['tag_id'];?>"><?php echo $value['tag_name'];?></option>
													<?php } ?>
												</select>
											</div>
										</div>

										<div class="form-group">
											<label class="col-sm-2 control-label">Longitude: </label>
											<div class="col-sm-10">
												<input type="text" name="longitude" class="form-control">
											</div>
										</div>

										<div class="form-group">
											<label class="col-sm-2 control-label">Latitude: </label>
											<div class="col-sm-10">
												<input type="text" name="latitude" class="form-control">
											</div>
										</div>


										<div class="form-group">
											<div class="col-sm-4 col-sm-offset-5">
												<button class="btn btn-default" type="submit">Cancel</button>
												<button class="btn btn-primary" type="submit">Save changes</button>
											</div>
										</div>

									</form>

								</div>
							</div>
						</div>
					</div>
				</div>


				<?php include 'templates/footer.php';?>