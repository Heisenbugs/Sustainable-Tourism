<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Places extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		/*$this->check_isvalidated();*/
		$this->load->model('Placesmodel');
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
	}

	public function index()
	{
		$data['Country'] = $this->Placesmodel->show_country();
		$data['City'] = $this->Placesmodel->show_city();
		$data['District'] = $this->Placesmodel->show_district();
		$data['Thana'] = $this->Placesmodel->show_thana();
		$data['Tags'] = $this->Placesmodel->show_tags();
		$data['Division'] = $this->Placesmodel->show_division();

		$this->load->view('Places',$data);
	}


	public function add_places()
	{	
		$this->form_validation->set_rules('city_id', 'City Name', 'required');
		$this->form_validation->set_rules('placename', 'Placename', 'required');
		
		if ($this->form_validation->run() == FALSE)
		{   
			$data['Country'] = $this->Placesmodel->show_country();
			$data['City'] = $this->Placesmodel->show_city();
			$data['District'] = $this->Placesmodel->show_district();	// this will be done in the frondend
			$data['Thana'] = $this->Placesmodel->show_thana();
			$data['Tags'] = $this->Placesmodel->show_tags();
			$data['Division'] = $this->Placesmodel->show_division();

			$this->load->view('Places',$data);		
		}    
		else
		{      
			$data = array(
				'city_id' => $this->input->post('city_id'),
				'country_id' => $this->input->post('country_id'),
				'district_id' => $this->input->post('district_id'),
				'division_id' => $this->input->post('division_id'),
				'thana_id' => $this->input->post('thana_id'),
				);
			$temp = $this->Placesmodel->add_address($data);
			$x = 0;
			foreach ($temp as $key => $value) {
				$x = $value;
			}
			$data = array(
				'place_name' => $this->input->post('placename'),
				'place_description' => $this->input->post('description'),
				'place_longitude' => $this->input->post('longitude'),
				'place_latitude' => $this->input->post('latitude'),
				'place_address' => $x
				);
			
			$temp = $this->Placesmodel->add_place($data);
			foreach ($temp as $key => $value) {
				$x = $value ;
			}

			$this->Placesmodel->add_tags($x, $this->input->post('tag_id[]'));
			redirect('index.php/Places');
		}

	}

}
/* End of file Places.php */

/* Location: ./application/controllers/Places.php */