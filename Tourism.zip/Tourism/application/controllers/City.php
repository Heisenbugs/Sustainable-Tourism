<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class City extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		/*$this->check_isvalidated();*/
		$this->load->model('Citymodel');
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
	}

	public function index()
	{	
		$data['country'] = $this->Citymodel->show_country();
		$this->load->view('City',$data);		
	}

	
	public function add_city()
	{	
		$this->form_validation->set_rules('cityname', 'City Name', 'required');
		$this->form_validation->set_rules('country_id', 'Country', 'required');
		
		if ($this->form_validation->run() == FALSE)
		{   
			$this->load->view('City');		
		}    
		else
		{      
			$data = array(
				'city_name' => $this->input->post('cityname'),
				'city_des' => $this->input->post('description'),
				'country_id' => $this->input->post('country_id')
				);
			$this->Citymodel->add($data);
			redirect('index.php/dashboard');
		}

	}
}

/* End of file City.php */
/* Location: ./application/controllers/City.php */