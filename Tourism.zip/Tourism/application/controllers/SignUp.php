<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SignUp extends CI_Controller {

	function __construct(){

		parent::__construct();
		$this->load->model('LoginModel');
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
	}

	public function index()
	{
		$this->load->view('SignupView');
	}
/*
	public function signup()
	{
		// echo json_encode($this->input->post());
		// exit();
		// $this->load->model('user_model');
		// $this->user_model->create_user($this->input->post());


		// $data = array(
		// 	'success' => true,
		// 	'message' => 'signup successfull',
		// 	'username' => 'siam' 
		// 	);
		$data = array(
			'success' => false,
			'message' => 'signup failed try again later'
			);
		echo json_encode($data);
	}*/

}

/* End of file SignUp.php */
/* Location: ./application/controllers/SignUp.php */
?>