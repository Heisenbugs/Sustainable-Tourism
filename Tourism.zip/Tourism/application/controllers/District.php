<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class District extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		/*$this->check_isvalidated();*/
		$this->load->model('Districtmodel');
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
	}

	public function index()
	{
		$this->load->view('District');
	}

	public function add_district()
	{	
		$this->form_validation->set_rules('districtname', 'District Name', 'required');
		
		if ($this->form_validation->run() == FALSE)
		{   
			$this->load->view('City');		
		}    
		else
		{      
			$data = array(
				'district_name' => $this->input->post('districtname'),
				'district_description' => $this->input->post('description'),
				);
			$this->Districtmodel->add($data);
			redirect('index.php/dashboard');
		}

	}

}

/* End of file District.php */
/* Location: ./application/controllers/District.php */