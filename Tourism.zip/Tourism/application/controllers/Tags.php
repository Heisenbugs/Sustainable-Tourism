<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tags extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		/*$this->check_isvalidated();*/
		$this->load->model('Tagsmodel');
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
	}

	public function index()
	{	
		$this->load->view('Tags');
	}

	public function add_tags()
	{	
		$this->form_validation->set_rules('tagname', 'Tag Name', 'required');
		
		if ($this->form_validation->run() == FALSE)
		{   
			$this->load->view('City');		
		}    
		else
		{      
			$data = array(
				'tag_name' => $this->input->post('tagname'),
				'tag_description' => $this->input->post('description'),
				);
			$this->Tagsmodel->add($data);
			redirect('index.php/dashboard');
		}

	}

}

/* End of file Tags.php */
/* Location: ./application/controllers/Tags.php */