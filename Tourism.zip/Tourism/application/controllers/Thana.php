<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Thana extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		/*$this->check_isvalidated();*/
		$this->load->model('Thanamodel');
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
	}

	public function index()
	{
		$this->load->view('Thana');
	}


	public function add_thana()
	{	
		$this->form_validation->set_rules('thananame', 'Thana Name', 'required');
		$this->form_validation->set_rules('code', 'Thana Code', 'required');
		
		if ($this->form_validation->run() == FALSE)
		{   
			$this->load->view('Thana');		
		}    
		else
		{      
			$data = array(
				'thana_name' => $this->input->post('thananame'),
				'thana_code' => $this->input->post('code'),
				);
			$this->Thanamodel->add($data);
			redirect('index.php/dashboard');
		}

	}
}

/* End of file Thana.php */
/* Location: ./application/controllers/Thana.php */