<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Division extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		/*$this->check_isvalidated();*/
		$this->load->model('Divisionmodel');
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
	}


	public function index()
	{
		$this->load->view('Division');		
	}

	public function add_division()
	{	
		$this->form_validation->set_rules('divisionname', 'Division Name', 'required');
		
		if ($this->form_validation->run() == FALSE)
		{   
			$this->load->view('Division');		
		}    
		else
		{      
			$data = array(
				'division_name' => $this->input->post('divisionname'),
				'division_description' => $this->input->post('description'),
				);

			$this->Divisionmodel->add($data);
			redirect('index.php/dashboard');
		}

	}

}

/* End of file Division.php */
/* Location: ./application/controllers/Division.php */