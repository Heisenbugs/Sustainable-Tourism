<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Country extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		/*$this->check_isvalidated();*/
		$this->load->model('Countrymodel');
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
	}

	public function index()
	{
		$this->load->view('Country');
	}

	public function add_country()
	{
		$this->form_validation->set_rules('countryname', 'Country Name', 'required');
		$this->form_validation->set_rules('code', 'Country', 'required');
		
		if ($this->form_validation->run() == FALSE)
		{   
			$this->load->view('Country');		
		}    
		else
		{      
			$data = array(
				'country_name' => $this->input->post('countryname'),
				'country_code' => $this->input->post('code'),
				);
			$this->Countrymodel->add($data);
			redirect('index.php/dashboard');
		}

	}
}


/* End of file Country.php */
/* Location: ./application/controllers/Country.php */